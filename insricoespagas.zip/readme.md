
Use o shortcode `[inscricoes_pagas]` em qualquer página para exibir a tabela de inscrições.

Para filtrar por produto específico, use: `[inscricoes_pagas product_id="123"]`

