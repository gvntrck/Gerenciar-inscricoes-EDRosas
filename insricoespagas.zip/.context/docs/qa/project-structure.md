---
slug: project-structure
category: architecture
generatedAt: 2026-01-19T18:39:23.484Z
---

# How is the codebase organized?

## Project Structure

```
assets/
includes/
templates/
```
