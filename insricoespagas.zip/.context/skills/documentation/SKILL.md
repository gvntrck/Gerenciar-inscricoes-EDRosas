---
type: skill
name: Documentation
description: Generate and update technical documentation
skillSlug: documentation
phases: [P, C]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
