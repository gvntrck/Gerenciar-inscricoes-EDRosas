---
type: skill
name: Test Generation
description: Generate comprehensive test cases for code
skillSlug: test-generation
phases: [E, V]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
