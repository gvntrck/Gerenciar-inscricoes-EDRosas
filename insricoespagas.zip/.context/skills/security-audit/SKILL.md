---
type: skill
name: Security Audit
description: Security review checklist for code and infrastructure
skillSlug: security-audit
phases: [R, V]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
