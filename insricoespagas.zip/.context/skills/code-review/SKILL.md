---
type: skill
name: Code Review
description: Review code quality, patterns, and best practices
skillSlug: code-review
phases: [R, V]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
