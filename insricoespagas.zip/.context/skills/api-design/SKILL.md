---
type: skill
name: Api Design
description: Design RESTful APIs following best practices
skillSlug: api-design
phases: [P, R]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
