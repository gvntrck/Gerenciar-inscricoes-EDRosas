---
type: skill
name: Feature Breakdown
description: Break down features into implementable tasks
skillSlug: feature-breakdown
phases: [P]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
