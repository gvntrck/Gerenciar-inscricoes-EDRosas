---
type: skill
name: Refactoring
description: Safe code refactoring with step-by-step approach
skillSlug: refactoring
phases: [E]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
