---
type: skill
name: Pr Review
description: Review pull requests against team standards and best practices
skillSlug: pr-review
phases: [R, V]
generated: 2026-01-19
status: unfilled
scaffoldVersion: "2.0.0"
---
